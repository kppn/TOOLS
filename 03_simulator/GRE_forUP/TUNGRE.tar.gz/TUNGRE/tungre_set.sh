#!/usr/bin/perl

$device = "tungre";
$GWU = '192.168.1.161';        #GWU��IP���ɥ쥹������
$IMSI= '440101540040304';    #��ǻ��Ѥ���IMSI������
$RSH = '/usr/bin/rsh';

$AFPDEBUG = '/usr/local/6bin/afpdebug';


sub get_iid() {
	my $original = $_[0];
	my @address;
	my $interfaceId;

	if ($original =~ /::/) {
		# û�̷�����Ÿ������
		my ($adr_a, $adr_b) = split /::/, $original;
		my @adr_a = split /:/, $adr_a;
		my @adr_b = split /:/, $adr_b;
		for (scalar @adr_a .. 7 - scalar @adr_b) {
		    push @adr_a, 0
		};
		@address = (@adr_a, @adr_b);
	} else {
		@address = split /:/, $original;
	}

	foreach $i (@address) {
		$exp .= sprintf("%04s:", $i)
	}
	chop($exp);

	@tmp = split(/:/, $exp);
	$interfaceId = join(':', @tmp[4..7]);
}


#
# print usage
#
sub usage() {
print <<EOL;

tungre_set.sh [-n gwp|pgw] [-c n] [-r4 (ipv4_route/mask)] [-r6 (ipv6_route/pref_len)]

  command line options

     delete all exisit gre tunnel
	-d

     node setting
	-n sgw: perform S-GW side for P-GW
	-n pgw: perform P-GW side for S-GW

	    default: sgw

     connection selection

	-c n: select connection number when Multi connected;
	    default: first idx of 'echo find | afpdebug'.

     address setting

        -a4 xxx.xxx.xxx.xxx  : set IPv4 addr
	-a6 xxxx:xxxx::xxxx  : set IPv6 addr

     route setting

	-r4 xxx.xxx.xxx.xxx/xx  : set IPv4 route
	-r6 xxxx:xxxx::xxxx/xxx : set IPv6 route

EOL
}

if ( @ARGV == 1 and
     $ARGV[0] eq "-d") {
	@exist_tunnels = `iptunnel | grep tungre | perl -pe 's/:.*//'`;
	foreach $exist_tunnel (@exist_tunnels) {
		`iptunnel del $exist_tunnel`;
	}
	exit(1);
}


%options = ("node"	=> "sgw",
	    "connection" => "",
	    "addr4"	=> "",
	    "addr6"	=> "",
	    "route4"	=> "",
	    "route6"	=> ""
	    );

for ($i = 0; $i <= $#ARGV; $i++) {
	if ($ARGV[$i] eq '-n') {
		if (($ARGV[$i+1] eq 'sgw') or 
		    ($ARGV[$i+1] eq 'pgw')   ) {
			$options{"node"} = $ARGV[$i+1];
		}
		else {
			usage();
			exit;
		}
	}
	if ($ARGV[$i] eq '-c') {
		$options{"connection"} = $ARGV[$i+1];
		$i++;
	}
	if ($ARGV[$i] eq '-a4') {
		if ($ARGV[$i+1] eq "") {
			usage();
			exit;
		}
		$options{"addr4"} = $ARGV[$i+1];
		$i++;
	}
	if ($ARGV[$i] eq '-a6') {
		if ($ARGV[$i+1] eq "") {
			usage();
			exit;
		}
		$options{"addr6"} = $ARGV[$i+1];
		$i++;
	}
	if ($ARGV[$i] eq '-r4') {
		if ($ARGV[$i+1] eq "") {
			usage();
			exit;
		}
		$options{"route4"} = $ARGV[$i+1];
		$i++;
	}
	if ($ARGV[$i] eq '-r6') {
		if ($ARGV[$i+1] eq "") {
			usage();
			exit;
		}
		$options{"route6"} = $ARGV[$i+1];
		$i++;
	}
	if ($ARGV[$i] eq '-h') {
		usage();
		exit;
	}
} 




# End User Address. from afpdebug find

$afpdebug_cmd = "'echo find | $AFPDEBUG'";
$cmd_gbtrc = "./exec_command_gwu.sh $GWU $afpdebug_cmd";
@afpdebug_find = `$cmd_gbtrc`;

FIND_SESSION: foreach $line (@afpdebug_find) {
	if ($line =~ /^([0-9]{6}) /) {
		if ($options{"connection"} eq "") {
			$connection = $1;
			last FIND_SESSION;
		}
		else {
			if ($1 == $options{"connection"}) {
				$line_found = $line;
				$connection = $1;
				last FIND_SESSION;
			}
		}
	}
}
if ($connection eq "") {
	print "connection $options{'connection'} not exist.\n";
	print "\n";
	print @afpdebug_find;
	print "\n";
	exit;
}

$line_found =~ /^([0-9a-z]+).* ([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})[ \t]+([0-9a-z:]+)/;
$idx = $1;
$euipv4 = $2;
$euipv6 = $3;


# Node IP Address and GRE Key. from afpdebug dump

$afpdebug_cmd = "'echo dump $connection | $AFPDEBUG'";
$cmd_gbtrc = "./exec_command_gwu.sh $GWU $afpdebug_cmd | grep 'if2 info' -A 14";
@afpdebug_dump = `$cmd_gbtrc`;


# determine device number. e.g.) tungre0, tungre1 ..

$max_exist_tunnel_num = -1;

@exist_tunnels = `iptunnel | grep tungre | perl -pe 's/:.*//'`;
foreach $exist_tunnel (@exist_tunnels) {
	$tunnel_usage{$exist_tunnel} = 1;

	$exist_tunnel =~ /$device([0-9]+)/;
	$tunnel_num = $1;
	$max_exist_tunnel_num = $tunnel_num;
}

if ($max_exist_tunnel_num == -1) {
	$tunnel_num = 0;
}
elsif ($max_exist_tunnel_num < 19) {
	$tunnel_num = $max_exist_tunnel_num + 1;
}
else {
	FIND_FREE_TUNNEL_NUM: for ($i = 0; $i < 19; $i++) {
		$tmp_device = $device . $i;
		if ($tunnel_usage{$tmp_device} == undef) {
			$tunnel_num = $i;
			last FIND_FREE_TUNNEL_NUM;
		}
	}
}


$device = $device . $tunnel_num;




if ($options{"node"} eq "sgw" or $options{"node"} eq "pgw") {
	foreach $line (@afpdebug_dump) {
		$grekey_remote = $1 if $line =~ /own_grekey += ([0-9a-zx]+)/;
		$grekey_own    = $1 if $line =~ /gre.key += ([0-9a-zx]+)/;

		$ipadr_remote  = $1 if $line =~ /ip.src_v4 += ([0-9a-z:\.]+)/;
		$ipadr_own     = $1 if $line =~ /ip.dst_v4 += ([0-9a-z:\.]+)/;
	}
}


$euipv4 = $options{"addr4"} if $options{"addr4"} ne "";
$euipv6 = $options{"addr6"} if $options{"addr6"} ne "";


$ikey = hex $grekey_own;
$okey = hex $grekey_remote;


system("iptunnel add $device mode gre local $ipadr_own remote $ipadr_remote ikey $ikey okey $okey ttl 255");
print "TUNNEL CREATE: $device \n";

system("ip link set $device up");

system("ip addr add ${euipv4}/32 dev $device") if $euipv4 ne "";
system("ip addr add ${euipv6}/64 dev $device") if $euipv6 ne "";

system("ip route add $options{'route4'} dev $device") if $options{"route4"} ne "";
system("ip route add $options{'route6'} dev $device") if $options{"route6"} ne "";

system("ip tunnel show | grep $device");

